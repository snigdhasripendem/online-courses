# EduLearn - Online Education Courses Website

A professional and responsive website for online education courses with a modern navigation bar and multiple feature pages.

## 📁 Project Structure

```
online Courses/
├── index.html          # Home page with hero section and featured courses
├── about.html          # About us page with mission and values
├── courses.html        # All courses page with search functionality
├── pages.html          # Additional pages with resources and services
├── help.html           # Help and FAQ page with support options
├── styles.css          # Main styling for navigation and home page
├── pages.css           # Additional styling for other pages
└── script.js           # JavaScript for interactivity
```

## 🎨 Features

### Navigation Bar
- **Sticky navbar** that stays at the top while scrolling
- Navigation items: Home, About, Courses, Pages, Help
- **Join Now button** positioned on the top right corner
- Responsive design that adapts to mobile devices
- Active state indicator for current page
- Smooth hover effects

### Pages Included

1. **Home (index.html)**
   - Hero section with call-to-action
   - Featured courses grid
   - Professional gradient design

2. **About (about.html)**
   - Mission statement
   - Company values
   - Why choose us section

3. **Courses (courses.html)**
   - Complete course catalog
   - Search functionality
   - Course filtering
   - Enroll buttons

4. **Pages (pages.html)**
   - Student resources
   - Success stories
   - Instructor profiles
   - Community forum
   - Career services

5. **Help (help.html)**
   - FAQ section
   - Contact information
   - Troubleshooting guide
   - Live chat support option

## 🚀 How to Use

1. **Open in Browser**: Simply open `index.html` in your web browser to view the website.

2. **Navigate**: Use the navigation bar to move between different pages.

3. **Search Courses**: On the Courses page, use the search box to filter courses.

4. **Join/Enroll**: Click the "Join Now" button in the navbar or enrollment buttons on courses to simulate registration.

## 🎯 Key Features

- ✅ Fully responsive design (works on mobile, tablet, desktop)
- ✅ Professional gradient color scheme
- ✅ Smooth animations and transitions
- ✅ Interactive elements with hover effects
- ✅ Search functionality for courses
- ✅ FAQ section with expandable items
- ✅ Sticky navigation bar
- ✅ Mobile-friendly hamburger menu ready
- ✅ Professional typography and spacing

## 🛠️ Customization

### Colors
Edit the gradient colors in `styles.css`:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Content
Update course names, descriptions, and prices in `courses.html`.

### Branding
- Replace "EduLearn" logo with your brand name in the navbar
- Update course descriptions and content as needed

## 📱 Responsive Breakpoints

- **Desktop**: Full layout
- **Tablet** (768px and below): Adjusted navigation and grid
- **Mobile** (480px and below): Single column layout, mobile-optimized navigation

## 🔧 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 📝 Notes

- All pages include the same navigation bar for consistent user experience
- Each page has a page header with title
- Footer is included on all pages
- JavaScript handles interactivity and form submissions
- No external dependencies - pure HTML, CSS, and JavaScript

## 🎓 Course Data

The website currently includes placeholder courses:
- Web Development ($49.99)
- Data Science ($59.99)
- Digital Marketing ($44.99)
- Mobile App Development ($64.99)
- UI/UX Design ($54.99)
- Cloud Computing ($69.99)

You can easily modify these to include your actual courses.

---

**Created**: 2024
**License**: Free to use and modify
