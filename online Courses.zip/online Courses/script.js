// Navigation active state
document.addEventListener('DOMContentLoaded', function() {
    updateActiveNav();
    
    // Add search functionality to courses page
    const searchInput = document.getElementById('courseSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', filterCourses);
    }

    // Add click handlers for forms
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLoginSubmit);
    }

    const registerForm = document.querySelector('.register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegisterSubmit);
    }

    const ctaBtn = document.querySelector('.cta-btn');
    if (ctaBtn) {
        ctaBtn.addEventListener('click', function() {
            handleCTAClick();
        });
    }

    const enrollButtons = document.querySelectorAll('.enroll-btn');
    enrollButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            handleEnrollClick();
        });
    });

    // FAQ toggle functionality
    const faqItems = document.querySelectorAll('.faq-item h4');
    faqItems.forEach(item => {
        item.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            if (answer) {
                answer.style.display = answer.style.display === 'none' ? 'block' : 'none';
            }
        });
    });

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const loginModal = document.getElementById('loginModal');
        const registerModal = document.getElementById('registerModal');
        if (event.target === loginModal) {
            closeLoginModal();
        }
        if (event.target === registerModal) {
            closeRegisterModal();
        }
    });
});

// Modal Functions
function openLoginModal() {
    const modal = document.getElementById('loginModal');
    modal.classList.add('show');
}

function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    modal.classList.remove('show');
}

function openRegisterModal() {
    const modal = document.getElementById('registerModal');
    modal.classList.add('show');
}

function closeRegisterModal() {
    const modal = document.getElementById('registerModal');
    modal.classList.remove('show');
}

function openJoinModal() {
    openRegisterModal();
}

function switchToRegister() {
    closeLoginModal();
    openRegisterModal();
}

function switchToLogin() {
    closeRegisterModal();
    openLoginModal();
}

// Form Handlers
function handleLoginSubmit(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    if (email && password) {
        alert(`Welcome back!\n\nLogged in with: ${email}`);
        closeLoginModal();
        // Clear form
        e.target.reset();
    }
}

function handleRegisterSubmit(e) {
    e.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }
    
    if (!agreeTerms) {
        alert('Please agree to the Terms and Conditions');
        return;
    }
    
    if (name && email && password) {
        alert(`Welcome to EduLearn!\n\nAccount created for: ${name}\nEmail: ${email}`);
        closeRegisterModal();
        // Clear form
        e.target.reset();
    }
}

// Update active navigation item based on current page
function updateActiveNav() {
    const currentLocation = location.pathname;
    const menuItems = document.querySelectorAll('.nav-link');
    
    menuItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('href') === currentLocation.split('/').pop() || 
            (currentLocation.includes('index.html') && item.getAttribute('href') === 'index.html')) {
            item.classList.add('active');
        }
    });
}

// Handle CTA button click
function handleCTAClick() {
    alert('Get started with your learning journey today!');
    // Scroll to courses or redirect to courses page
    window.location.href = 'courses.html';
}

// Handle Enroll button click
function handleEnrollClick(event) {
    const courseName = event.target.previousElementSibling.querySelector('h3')?.textContent || 'this course';
    alert(`You're about to enroll in: ${courseName}\n\nPlease login or register to continue.`);
    openLoginModal();
}

// Filter courses based on search input
function filterCourses() {
    const searchValue = document.getElementById('courseSearch').value.toLowerCase();
    const courseCards = document.querySelectorAll('.course-card');
    
    courseCards.forEach(card => {
        const courseName = card.querySelector('h3').textContent.toLowerCase();
        const courseDesc = card.querySelector('p').textContent.toLowerCase();
        
        if (courseName.includes(searchValue) || courseDesc.includes(searchValue)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Add scroll effect to navbar
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.2)';
    } else {
        navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    }
});

// Lazy loading for images (performance optimization)
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
}
